// code goes here

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdint.h>
#include <err.h>
#include <sys/stat.h>
#include <stdio.h>

void set(const int64_t tar,const int64_t val, int64_t* log, const uint32_t size);
void load(const int64_t to,const int64_t from_ptr, int64_t* log, const uint32_t size);
void store(const int64_t to_ptr,const int64_t from, int64_t* log, const uint32_t size);
void jmp(const int64_t idx, int64_t* log, const uint32_t size, const int fd);
void sgz(const int64_t v, int64_t* log, const uint32_t size, const int fd);
void add(const int64_t res,const int64_t v1,const int64_t v2, int64_t* log, const uint32_t size);
void mul(const int64_t res,const int64_t v1,const int64_t v2, int64_t* log, const uint32_t size);
void _div(const int64_t res,const int64_t v1, const int64_t v2, int64_t* log, const uint32_t size);
void mod(const int64_t res,const int64_t v1, const int64_t v2, int64_t* log, const uint32_t size);
void out(const int64_t v, int64_t* log, const uint32_t size);
void _sleep(const int64_t v);

struct operation{
	uint8_t command;
	int64_t operand[3];
}__attribute__((packed));

int main(const int argc, const char* argv[]){

	if(argc != 2){
		errx(1, "Too little/much arguments! You only need 1\n");
	}

	char magicWord[3];
	uint32_t ram_size;
	
	//open file	
	int fd;
	if((fd = open(argv[1], O_RDONLY)) == -1){
		err(2, "Can't open file");
	}
	
	//size of file
	struct stat fs;
	if(fstat(fd, &fs) == -1){
		err(5,"Can't get fstat");
	}
	if((fs.st_size - (3 + sizeof(uint32_t))) % 25 != 0){
		err(6, "filesize is not right");
	}
	
	//magic word
	if(read(fd, &magicWord[0],1) == -1 || read(fd, &magicWord[1],1) == -1 || read(fd, &magicWord[2],1) == -1){
		err(3,"Error while reading magicWord");
	}
	if(magicWord[0] != 'O' || magicWord[1] != 'R' || magicWord[2] != 'C'){
		errx(10, "Wrong magic word");
	}
	
	//ram size
	if(read(fd, &ram_size, sizeof(ram_size)) != sizeof(ram_size)){
		err(3,"Error while reading ram_size");
	}
	
	int64_t* log = malloc(ram_size*sizeof(int64_t));
	int r;
	struct operation o;

	while((r = read(fd, &o, sizeof(o))) == sizeof(o)){
		switch(o.command){
			case 0x00:
				break;
			case 0x95:
				set(o.operand[0], o.operand[1], log, ram_size);
				break;
			case 0x5d:
				load(o.operand[0],o.operand[1], log, ram_size);
				break;
			case 0x63:
				store(o.operand[0], o.operand[1], log, ram_size);
				break;
			case 0x91:
				jmp(o.operand[0], log, ram_size, fd);
				break;
			case 0x25:
				sgz(o.operand[0], log, ram_size, fd);
				break;
			case 0xAD:
				add(o.operand[0], o.operand[1], o.operand[2], log, ram_size);
				break;
			case 0x33:
				mul(o.operand[0], o.operand[1], o.operand[2], log, ram_size);				
				break;
			case 0x04:
				_div(o.operand[0], o.operand[1], o.operand[2], log, ram_size);	
				break;
			case 0xB5:
				mod(o.operand[0], o.operand[1], o.operand[2], log, ram_size);
				break;
			case 0xC1:
				out(o.operand[0], log, ram_size);
				break;
			case 0xBF:
				sleep(o.operand[0]);
				break;
			default:
				err(6,"Invalid instruction %d", o.command);
				break;
		}
	}

	free(log);

	if(r == -1){
		err(4, "Error while reading operand");
	}

	close(fd);
	exit(0);
}

void set(const int64_t tar,const int64_t val, int64_t* log,const uint32_t size){
	if(size <= tar || tar < 0){
		errx(8, "Invalid address");
	}
	log[tar] = val;
}

void load(const int64_t to,const int64_t from_ptr, int64_t* log, const uint32_t size){
	if(to >= size || to < 0 || from_ptr >= size || from_ptr < 0){
		errx(8, "Invalid address");
	}

	if(log[from_ptr] >= size || log[from_ptr] < 0){
		errx(8, "Invalid address");
	}	

	log[to] = log[log[from_ptr]];
}
void store(const int64_t to_ptr,const int64_t from, int64_t* log, const uint32_t size){
	if(to_ptr >= size || to_ptr < 0 || from >= size || from < 0){
		errx(8, "Invalid address");
	}

	if(log[to_ptr] >= size || log[to_ptr] < 0 ){
		errx(8, "Invalid address");
	}

	log[log[to_ptr]] = log[from];
}
void jmp(const int64_t idx, int64_t* log, const uint32_t size, const int fd){
		if(size <= idx || idx < 0){
		errx(8, "Invalid address");
	}
	
	if(lseek(fd, 3 + sizeof(uint32_t) + log[idx]*sizeof(struct operation), SEEK_SET) == -1){
		errx(11, "err with lseek in sgz");
	}

}
void sgz(const int64_t v, int64_t* log, const uint32_t size, const int fd){
	if(size <= v || v < 0){
		errx(8, "Invalid address");
	}

	if(log[v] > 0){
		if(lseek(fd, sizeof(struct operation), SEEK_CUR) == -1){
			errx(11, "err with lseek in sgz");
		}
	}
}
void add(const int64_t res,const int64_t v1,const int64_t v2, int64_t* log, const uint32_t size){
	if(size <= res || res < 0 || size <= v2 || v2 < 0 || size <= v2 || v2 < 0){
		errx(8, "Invalid address");
	}
	log[res] = log[v1] + log[v2];
}
void mul(const int64_t res,const int64_t v1,const int64_t v2, int64_t* log, const uint32_t size){
	if(size <= res || res < 0 || size <= v2 || v2 < 0 || size <= v2 || v2 < 0){
		errx(8, "Invalid address");
	}
	log[res] = log[v1] * log[v2];
}

void _div(const int64_t res,const int64_t v1, const int64_t v2, int64_t* log, const uint32_t size){
	if(size <= res || res < 0 || size <= v2 || v2 < 0 || size <= v2 || v2 < 0){
		errx(8, "Invalid address");
	}
	if(log[v2] == 0){
		errx(9, "Dividing by 0");
	}

	log[res] = log[v1] / log[v2];
}
void mod(const int64_t res,const int64_t v1, const int64_t v2, int64_t* log, const uint32_t size){
	if(size <= res || res < 0 || size <= v2 || v2 < 0 || size <= v2 || v2 < 0){
		errx(8, "Invalid address");
	}
	if(log[v2] == 0){
		errx(9, "Dividing by 0");
	}

	log[res] = log[v1] % log[v2];
}
void out(const int64_t v, int64_t* log, const uint32_t size){
	if(size <= v || v < 0){
		errx(8, "Invalid address");
	}
	write(1, &log[v], sizeof(log[v]));
}
void _sleep(const int64_t v){
	sleep(v/1000);
}

