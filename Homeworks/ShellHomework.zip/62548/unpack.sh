#! /bin/bash

[ $# -eq 4 ] && [ ! -e "$2" ] && [ ! -e "$3" ] && [ ! -e "$4"  ]  || exit 1

if [ -f "$1" -a -n "$(echo "$1" | egrep '.zip$')" ] 
then 
	mkdir "$2"
	mkdir "$3"
	touch "$1"

	#unarchive zip
	tmpDir=$(mktemp -d)
	unzip "$1" -d ${tmpDir} >/dev/null || exit 1
	
	fn="11111"

	for d in ${tmpDir}/*; do
		fn=$(echo "$d" | cut -d "-" -f 1 | cut -d / -f 4)
			gri=0
			grf=0
			nd=0
			grd=0
			remove=0

		#more than one file in moodle
		if [ $(find $d -maxdepth 1 -mindepth 1 | wc -l) -gt 1 ]
		then remove=1
		fi
		
		#uncompress and unarchive
		if [ ${remove} -eq 0 ]
		then
			f="$(echo "$d"/*)"
			#wrong name or extention
			if [ "$(echo "$f" | cut -d / -f 5 | cut -d . -f 1)" != ${fn} -o -z "$(echo "$f" | cut -d / -f 5 | egrep -n '*.tar.xz$')" ] 
			then
				gri=1
			fi

			#uncommpress
			if [ -z "$(file $f | cut -d : -f 2 | egrep 'XZ')" ]
			then
				grf=1			
				if [ -n "$(file $f | cut -d : -f 2 | egrep 'gzip')" ]
				then 
					mv $f "$f.gz" 2>/dev/null
					gunzip "$f.gz" 2>/dev/null
				elif [ -n "$(file $f | cut -d : -f 2| egrep 'bzip2')"  ]
			   	then
					bunzip2 "$f" 2>/dev/null
				else remove=1	
				fi
			else unxz "$f" 2>/dev/null
			fi
		
			original=$f	
			f=$(find $d -maxdepth 1 -mindepth 1)
			#archive
			if [ -z "$(file $f | cut -d : -f 2 | egrep 'tar')" ]
			then
				grf=1
				if [ -n "$(file $f | cut -d : -f 2| egrep 'Zip')"  ]
				then
					unzip $f -x '__MACOSX/*' -d "$d" >/dev/null 2>/dev/null
					remove=0
				elif [ -n "$(file $f | cut -d : -f 2 | egrep 'RAR')" ]
				then 
					unrar x $f $d >/dev/null 2>/dev/null
					remove=0
				fi
			else
			   	tar -xf "$f" -C "$d" >/dev/null 2>/dev/null
				remove=0
			fi
		fi

			#send to failed
			if [ ${remove} -eq 1 ]
			then
				if [ $( find $d -maxdepth 1 -mindepth 1 -type d | wc -l) -eq 1  ]
				then
					mv "$(find $d -mindepth 1 -maxdepth 1 -type d)" "$d/${fn}" 2>/dev/null
				   	cp -r "$d/${fn}" "$3" 2>/dev/null
				else 
					cp -r "$d" "$3/${fn}" 2>/dev/null
				fi
				continue
			fi

			rm "$f" 2>/dev/null
			rm "${original}" 2>/dev/null
			
			#file with wrong name
			if [ "$(find $d -mindepth 1 -maxdepth 1 -type d)" != "$d/${fn}" ]
			then grd=1
			fi

			#send to second folder
			if [ $(find $d -maxdepth 1 -mindepth 1 -type d | wc -l ) -eq 1 ]
			then
				mv "$(find $d -mindepth 1 -maxdepth 1 -type d)" "$d/${fn}" 2>/dev/null
				cp -r "$d/${fn}" "$2" 2>/dev/null
			else
				nd=1
				cp -r "$d" "$2/${fn}" 2>/dev/null
			fi	
	
		if [ ${remove} -eq 0 ]		
		then
		echo "${fn} ${gri} ${grf} ${nd} ${grd}" >> "$4"
		fi

	done
	
	rm -r ${tmpDir}	

else
	exit 1
fi

