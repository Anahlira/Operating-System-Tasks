#!/bin/sh

echo "Brontosaurus" > dinosaur.txt