#! /bin/bash

rm result.txt
rm -r suc
rm -r unfinished
